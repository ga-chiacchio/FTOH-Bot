import wales_json from "./wales.json";
import {Circuit, CircuitInfo, Direction} from "../Circuit";

const WALES_INFO: CircuitInfo = {
    finishLine: {
        bounds: {
            minX: 5,
            maxX: 35,
            minY: -212,
            maxY: -22
        },
        passingDirection: Direction.RIGHT
    },
    name: "Trac Môn Tŷ Croes",
    boxLine: {
        minX: -528,
        maxX: -8,
        minY: -281,
        maxY: -211
    },
    pitlaneStart: {
        minX: -916,
        maxX: -858,
        minY: -202,
        maxY: -172
    },
    pitlaneEnd: {
        minX: 300,
        maxX: 333,
        minY: -450,
        maxY: -420
    },
    drsStart: [
        {
            minX: 0,
            maxX: 0,
            minY: 0,
            maxY: 0,
        },
        {
            minX: 0,
            maxX: 0,
            minY: 0,
            maxY: 0,
        }
    ],
    drsEnd: [
        {
            minX: 0,
            maxX: 0,
            minY: 0,
            maxY: 0,
        },
        {
            minX: 0,
            maxX: 0,
            minY: 0,
            maxY: 0,
        }
    ],
    checkpoints: [],
    lastPlace: {
        x: wales_json.redSpawnPoints[wales_json.redSpawnPoints.length - 1][0],
        y: wales_json.redSpawnPoints[wales_json.redSpawnPoints.length - 1][1],
    }
}

export const WALES: Circuit = {
    map: JSON.stringify(wales_json),
    info: WALES_INFO
}